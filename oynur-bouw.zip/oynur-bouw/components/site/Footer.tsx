import Link from "next/link";
import Image from "next/image";
import { Mail, MapPin, Phone, Clock } from "lucide-react";
import type { Locale, Settings } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { pagePath, servicePath } from "@/lib/routes";
import { services } from "@/lib/services";
import { telHref } from "@/lib/site";
import { SocialLinks } from "./SocialLinks";

export function Footer({ locale, settings }: { locale: Locale; settings: Settings }) {
  const t = getDictionary(locale);
  const year = new Date().getFullYear();
  const address = [settings.street, [settings.postalCode, settings.city].filter(Boolean).join(" ")].filter(Boolean);

  return (
    <footer className="relative overflow-hidden bg-ink text-white/70">
      <div className="blueprint absolute inset-0 opacity-60" aria-hidden="true" />
      <div className="container-x relative grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-12 lg:py-20">
        <div className="lg:col-span-4">
          <Link href={`/${locale}`} aria-label="Oynur Bouw B.V.">
            <Image src="/brand/logo-white.png" alt="Oynur Bouw B.V." width={220} height={44} className="h-9 w-auto" />
          </Link>
          <p className="mt-6 max-w-sm leading-relaxed">{settings.tagline[locale] || t.footer.about}</p>
          <div className="mt-6">
            <SocialLinks settings={settings} variant="dark" />
          </div>
        </div>

        <div className="lg:col-span-2">
          <h2 className="text-sm font-semibold tracking-wider text-white uppercase">{t.footer.navigation}</h2>
          <ul className="mt-5 space-y-3">
            {(["home", "services", "projects", "about", "contact"] as const).map((k) => (
              <li key={k}>
                <Link href={pagePath(locale, k)} className="transition hover:text-white">
                  {t.nav[k]}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-3">
          <h2 className="text-sm font-semibold tracking-wider text-white uppercase">{t.footer.services}</h2>
          <ul className="mt-5 space-y-3">
            {services.map((s) => (
              <li key={s.key}>
                <Link href={servicePath(locale, s.key)} className="transition hover:text-white">
                  {s.title[locale]}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div className="lg:col-span-3">
          <h2 className="text-sm font-semibold tracking-wider text-white uppercase">{t.footer.contact}</h2>
          <ul className="mt-5 space-y-4">
            {settings.phone && (
              <li>
                <a href={telHref(settings.phone)} className="flex items-start gap-3 transition hover:text-white">
                  <Phone className="mt-0.5 size-4 shrink-0 text-brand" /> {settings.phone}
                </a>
              </li>
            )}
            {settings.email && (
              <li>
                <a href={`mailto:${settings.email}`} className="flex items-start gap-3 break-all transition hover:text-white">
                  <Mail className="mt-0.5 size-4 shrink-0 text-brand" /> {settings.email}
                </a>
              </li>
            )}
            {address.length > 0 && (
              <li className="flex items-start gap-3">
                <MapPin className="mt-0.5 size-4 shrink-0 text-brand" />
                <address className="not-italic">
                  {address.map((l) => (
                    <span key={l} className="block">
                      {l}
                    </span>
                  ))}
                </address>
              </li>
            )}
            {settings.openingHours[locale] && (
              <li className="flex items-start gap-3">
                <Clock className="mt-0.5 size-4 shrink-0 text-brand" />
                <span className="whitespace-pre-line">{settings.openingHours[locale]}</span>
              </li>
            )}
          </ul>
        </div>
      </div>

      <div className="relative border-t border-white/10">
        <div className="container-x flex flex-col gap-3 py-6 text-sm sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {year} {(settings.companyName || "Oynur Bouw B.V.").replace(/\.$/, "")}. {t.footer.rights}
            {settings.kvk && <span className="ml-2">· {t.footer.kvk}: {settings.kvk}</span>}
            {settings.btw && <span className="ml-2">· {t.footer.btw}: {settings.btw}</span>}
          </p>
          <div className="flex gap-5">
            <Link href={pagePath(locale, "privacy")} className="hover:text-white">
              {t.privacy.title}
            </Link>
            <Link href={locale === "nl" ? "/en" : "/nl"} hrefLang={locale === "nl" ? "en" : "nl"} className="hover:text-white">
              {locale === "nl" ? "English" : "Nederlands"}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
