import Link from "next/link";
import { ArrowRight, Phone } from "lucide-react";
import type { Locale, Settings } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { pagePath } from "@/lib/routes";
import { telHref, whatsappHref } from "@/lib/site";
import { SocialIcon } from "@/components/SocialIcon";

export function CtaBanner({ locale, settings }: { locale: Locale; settings: Settings }) {
  const t = getDictionary(locale);
  return (
    <section className="container-x py-20 lg:py-28">
      <div className="relative overflow-hidden rounded-[2rem] bg-brand px-6 py-14 text-white sm:px-12 lg:px-16 lg:py-20">
        <div className="blueprint absolute inset-0 opacity-70" aria-hidden="true" />
        <svg
          className="absolute -right-24 -bottom-24 size-[420px] text-white/10"
          viewBox="0 0 100 100"
          aria-hidden="true"
        >
          <circle cx="50" cy="50" r="40" fill="none" stroke="currentColor" strokeWidth="14" />
        </svg>
        <div className="relative grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-center">
          <div>
            <h2 className="text-3xl leading-tight font-extrabold sm:text-4xl lg:text-5xl">{t.cta.title}</h2>
            <p className="mt-4 max-w-xl text-lg text-white/85">{t.cta.text}</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row lg:flex-col lg:items-end">
            <Link href={pagePath(locale, "contact")} className="btn bg-ink !px-7 !py-4 text-base text-white hover:bg-ink-800">
              {t.cta.button} <ArrowRight className="size-4" />
            </Link>
            {settings.phone && (
              <a href={telHref(settings.phone)} className="btn bg-white !px-7 !py-4 text-base text-ink hover:bg-white/90">
                <Phone className="size-4" /> {t.cta.call}: {settings.phone}
              </a>
            )}
            {settings.whatsapp && (
              <a
                href={whatsappHref(settings.whatsapp)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn border border-white/40 !px-7 !py-4 text-base text-white hover:bg-white/10"
              >
                <SocialIcon name="whatsapp" className="size-4" /> {t.cta.whatsapp}
              </a>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
