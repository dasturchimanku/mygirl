import { SocialIcon } from "@/components/SocialIcon";
import { whatsappHref } from "@/lib/site";

export function WhatsAppButton({ number, label }: { number: string; label: string }) {
  if (!number) return null;
  return (
    <a
      href={whatsappHref(number)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      title={label}
      className="fixed right-4 bottom-4 z-40 grid size-14 place-items-center rounded-full bg-[#25D366] text-white shadow-lift transition hover:scale-105 sm:right-6 sm:bottom-6"
    >
      <SocialIcon name="whatsapp" className="size-7" />
    </a>
  );
}
