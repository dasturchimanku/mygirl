import type { Settings, SocialKey } from "@/lib/types";
import { socialKeys } from "@/lib/types";
import { socialMeta } from "@/lib/socials";
import { SocialIcon } from "@/components/SocialIcon";

export function activeSocials(settings: Settings) {
  return socialKeys
    .filter((k) => /^https?:\/\//.test(settings.socials[k] || ""))
    .map((k) => ({ key: k as SocialKey, url: settings.socials[k], label: socialMeta[k].label }));
}

export function SocialLinks({
  settings,
  variant = "dark",
  size = "md",
}: {
  settings: Settings;
  variant?: "dark" | "light";
  size?: "md" | "lg";
}) {
  const items = activeSocials(settings);
  if (!items.length) return null;
  const base =
    variant === "dark"
      ? "bg-white/10 text-white hover:bg-brand hover:text-white"
      : "bg-ink/5 text-ink hover:bg-brand hover:text-white";
  const dim = size === "lg" ? "size-12" : "size-10";
  return (
    <ul className="flex flex-wrap gap-2.5">
      {items.map((s) => (
        <li key={s.key}>
          <a
            href={s.url}
            target="_blank"
            rel="noopener noreferrer me"
            aria-label={s.label}
            title={s.label}
            className={`${base} ${dim} inline-flex items-center justify-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand`}
          >
            <SocialIcon name={s.key} className={size === "lg" ? "size-5" : "size-[18px]"} />
          </a>
        </li>
      ))}
    </ul>
  );
}
