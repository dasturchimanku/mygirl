"use client";

import { useRef, useState, type ReactNode } from "react";

export function ProjectFilter({
  categories,
  allLabel,
  children,
}: {
  categories: { key: string; label: string; count: number }[];
  allLabel: string;
  children: ReactNode;
}) {
  const [active, setActive] = useState("all");
  const listRef = useRef<HTMLDivElement>(null);

  function select(key: string) {
    setActive(key);
    listRef.current?.querySelectorAll<HTMLElement>("[data-category]").forEach((el) => {
      el.hidden = key !== "all" && el.dataset.category !== key;
    });
  }

  const total = categories.reduce((n, c) => n + c.count, 0);
  const chip = (key: string, label: string, count: number) => (
    <button
      key={key}
      type="button"
      onClick={() => select(key)}
      aria-pressed={active === key}
      className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition ${
        active === key ? "bg-ink text-white" : "bg-white text-ink-700 ring-1 ring-line hover:ring-ink/30"
      }`}
    >
      {label}
      <span className={`text-xs ${active === key ? "text-white/60" : "text-stone"}`}>{count}</span>
    </button>
  );

  return (
    <>
      {categories.length > 1 && (
        <div className="mb-10 flex flex-wrap gap-2" role="group">
          {chip("all", allLabel, total)}
          {categories.map((c) => chip(c.key, c.label, c.count))}
        </div>
      )}
      <div ref={listRef}>{children}</div>
    </>
  );
}
