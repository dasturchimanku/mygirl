import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight, MapPin } from "lucide-react";
import type { Locale, Project } from "@/lib/types";
import { projectPath } from "@/lib/routes";
import { getService } from "@/lib/services";
import { coverOf } from "@/lib/projects";

export function ProjectCard({
  project,
  locale,
  priority,
  large,
}: {
  project: Project;
  locale: Locale;
  priority?: boolean;
  large?: boolean;
}) {
  const cover = coverOf(project);
  const service = getService(project.category);
  const title = project.title[locale] || project.title.nl;
  return (
    <Link
      href={projectPath(locale, project.slug)}
      className="group relative block h-full overflow-hidden rounded-[var(--radius-card)] bg-ink shadow-soft"
    >
      <div className={`relative ${large ? "aspect-[4/3] lg:aspect-auto lg:h-full lg:min-h-[520px]" : "aspect-[4/3]"}`}>
        {cover ? (
          <Image
            src={cover.src}
            alt={cover.alt[locale] || title}
            fill
            priority={priority}
            sizes={large ? "(min-width: 1024px) 66vw, 100vw" : "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw"}
            className="object-cover transition duration-700 group-hover:scale-105"
          />
        ) : (
          <div className="blueprint absolute inset-0 bg-ink-800" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent" />
      </div>
      <div className="absolute inset-x-0 bottom-0 p-5 text-white sm:p-6">
        {service && (
          <span className="mb-3 inline-block rounded-full bg-white/15 px-3 py-1 text-xs font-medium backdrop-blur">
            {service.title[locale]}
          </span>
        )}
        <h3 className="text-xl leading-snug font-bold">{title}</h3>
        {(project.location || project.year) && (
          <p className="mt-1.5 flex items-center gap-1.5 text-sm text-white/70">
            <MapPin className="size-3.5" />
            {[project.location, project.year].filter(Boolean).join(" · ")}
          </p>
        )}
      </div>
      <span className="absolute top-4 right-4 grid size-10 place-items-center rounded-full bg-white text-ink opacity-0 transition duration-300 group-hover:opacity-100">
        <ArrowUpRight className="size-5" />
      </span>
    </Link>
  );
}
