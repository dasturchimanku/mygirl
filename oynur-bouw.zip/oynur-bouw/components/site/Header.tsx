"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Phone, X, ArrowRight } from "lucide-react";
import type { Locale } from "@/lib/types";

type NavItem = { href: string; label: string };

type Props = {
  locale: Locale;
  nav: NavItem[];
  quote: { href: string; label: string };
  labels: { menu: string; close: string };
  phone: string;
  phoneHref: string;
  /** pairs of [nl, en] path segments/slugs used to translate the current URL */
  slugPairs: [string, string][];
};

function switchLocale(pathname: string, target: Locale, pairs: [string, string][]) {
  const parts = pathname.split("/").filter(Boolean);
  if (!parts.length) return `/${target}`;
  const from = parts[0] === "en" ? 1 : 0;
  const to = target === "en" ? 1 : 0;
  const out = parts.slice(1).map((seg) => {
    const pair = pairs.find((p) => p[from] === seg);
    return pair ? pair[to] : seg;
  });
  return `/${[target, ...out].join("/")}`;
}

export function Header({ locale, nav, quote, labels, phone, phoneHref, slugPairs }: Props) {
  const pathname = usePathname() || `/${locale}`;
  const isHome = pathname === `/${locale}` || pathname === `/${locale}/`;
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const transparent = isHome && !scrolled && !open;
  const other: Locale = locale === "nl" ? "en" : "nl";
  const otherHref = switchLocale(pathname, other, slugPairs);

  const isActive = (href: string) => (href === `/${locale}` ? isHome : pathname.startsWith(href));

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        transparent ? "bg-transparent text-white" : "border-b border-line/70 bg-paper/90 text-ink backdrop-blur-xl"
      }`}
    >
      <div className="container-x flex h-[72px] items-center justify-between gap-6 lg:h-20">
        <Link href={`/${locale}`} className="relative z-10 shrink-0" aria-label="Oynur Bouw B.V. – home">
          <Image
            src={transparent ? "/brand/logo-white.png" : "/brand/logo.png"}
            alt="Oynur Bouw B.V."
            width={200}
            height={40}
            priority
            className="h-8 w-auto lg:h-9"
          />
        </Link>

        <nav aria-label="Hoofdmenu" className="hidden items-center gap-1 lg:flex">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isActive(item.href) ? "page" : undefined}
              className={`relative rounded-full px-4 py-2 text-[15px] font-medium transition-colors ${
                isActive(item.href)
                  ? transparent
                    ? "text-white"
                    : "text-brand"
                  : transparent
                    ? "text-white/80 hover:text-white"
                    : "text-ink-700 hover:text-ink"
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          <Link
            href={otherHref}
            hrefLang={other}
            className={`rounded-full px-2.5 py-1.5 text-xs font-bold tracking-wider uppercase transition ${
              transparent ? "text-white/70 hover:text-white" : "text-stone hover:text-ink"
            }`}
            aria-label={other === "en" ? "English version" : "Nederlandse versie"}
          >
            {other}
          </Link>
          {phone && (
            <a
              href={phoneHref}
              className={`inline-flex items-center gap-2 text-sm font-semibold ${transparent ? "text-white" : "text-ink"}`}
            >
              <span className="grid size-9 place-items-center rounded-full bg-brand/15 text-brand">
                <Phone className="size-4" />
              </span>
              <span className="hidden xl:inline">{phone}</span>
            </a>
          )}
          <Link href={quote.href} className="btn-primary !py-2.5">
            {quote.label}
          </Link>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="relative z-10 -mr-2 grid size-11 place-items-center rounded-full lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? labels.close : labels.menu}
        >
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        hidden={!open}
        className="fixed inset-x-0 top-[72px] bottom-0 overflow-y-auto bg-paper text-ink lg:hidden"
      >
        <nav aria-label="Mobiel menu" className="container-x flex flex-col py-6">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center justify-between border-b border-line py-4 font-display text-2xl font-bold ${
                isActive(item.href) ? "text-brand" : ""
              }`}
            >
              {item.label}
              <ArrowRight className="size-5 text-stone" />
            </Link>
          ))}
          <div className="mt-8 flex flex-col gap-3">
            <Link href={quote.href} className="btn-primary w-full !py-4 text-base">
              {quote.label}
            </Link>
            {phone && (
              <a href={phoneHref} className="btn-ghost w-full !py-4 text-base">
                <Phone className="size-4" /> {phone}
              </a>
            )}
            <Link href={otherHref} hrefLang={other} className="mt-2 text-center text-sm font-semibold text-stone uppercase">
              {other === "en" ? "English" : "Nederlands"}
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
