import type { ReactNode } from "react";
import { Breadcrumbs, type Crumb } from "./Breadcrumbs";

export function PageHero({
  eyebrow,
  title,
  text,
  crumbs,
  children,
}: {
  eyebrow?: string;
  title: string;
  text?: string;
  crumbs: Crumb[];
  children?: ReactNode;
}) {
  return (
    <section className="relative overflow-hidden bg-ink pt-32 pb-16 text-white lg:pt-40 lg:pb-24">
      <div className="blueprint absolute inset-0" aria-hidden="true" />
      <div
        className="absolute -top-40 -right-40 size-[520px] rounded-full bg-brand/25 blur-[120px]"
        aria-hidden="true"
      />
      <div className="container-x relative">
        <Breadcrumbs items={crumbs} dark />
        {eyebrow && <p className="eyebrow mt-8">{eyebrow}</p>}
        <h1 className="mt-4 max-w-4xl text-4xl leading-[1.05] font-extrabold sm:text-5xl lg:text-6xl">{title}</h1>
        {text && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/70">{text}</p>}
        {children}
      </div>
    </section>
  );
}
