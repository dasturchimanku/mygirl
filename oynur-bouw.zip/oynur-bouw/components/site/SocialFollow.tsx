import type { Locale, Settings } from "@/lib/types";
import { SocialIcon } from "@/components/SocialIcon";
import { activeSocials } from "./SocialLinks";
import { ArrowUpRight } from "lucide-react";

const copy = {
  nl: { eyebrow: "Social media", title: "Volg ons werk", text: "Bekijk dagelijkse updates, voor-en-na video's en een kijkje achter de schermen op onze kanalen." },
  en: { eyebrow: "Social media", title: "Follow our work", text: "See daily updates, before-and-after videos and a look behind the scenes on our channels." },
};

function handleFrom(url: string) {
  try {
    const u = new URL(url);
    const part = u.pathname.split("/").filter(Boolean).pop();
    return part ? (part.startsWith("@") ? part : `@${part}`) : u.hostname.replace("www.", "");
  } catch {
    return url;
  }
}

export function SocialFollow({ locale, settings }: { locale: Locale; settings: Settings }) {
  const items = activeSocials(settings);
  if (!items.length) return null;
  const c = copy[locale];
  return (
    <section className="container-x pt-20 lg:pt-28" aria-labelledby="follow-title">
      <div className="text-center">
        <p className="eyebrow justify-center">{c.eyebrow}</p>
        <h2 id="follow-title" className="mt-4 text-3xl font-extrabold sm:text-4xl">
          {c.title}
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-lg text-stone">{c.text}</p>
      </div>
      <ul className="mx-auto mt-10 grid max-w-5xl gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((s) => (
          <li key={s.key}>
            <a
              href={s.url}
              target="_blank"
              rel="noopener noreferrer me"
              className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-4 transition hover:-translate-y-0.5 hover:border-brand/40 hover:shadow-soft"
            >
              <span className="grid size-12 shrink-0 place-items-center rounded-xl bg-ink text-white transition group-hover:bg-brand">
                <SocialIcon name={s.key} className="size-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-semibold">{s.label}</span>
                <span className="block truncate text-sm text-stone">{handleFrom(s.url)}</span>
              </span>
              <ArrowUpRight className="size-5 text-stone transition group-hover:text-brand" />
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
