"use client";

import Link from "next/link";
import { useActionState } from "react";
import { CircleCheck, CircleAlert, Loader2, Send } from "lucide-react";
import { submitContact, type ContactState } from "@/app/[lang]/contact/actions";
import type { Dictionary } from "@/lib/i18n";

type Props = {
  locale: string;
  t: Dictionary["contact"]["form"];
  services: { key: string; label: string }[];
  privacyHref: string;
};

export function ContactForm({ locale, t, services, privacyHref }: Props) {
  const [state, action, pending] = useActionState<ContactState, FormData>(submitContact, { status: "idle" });
  const err = (f: string) => {
    const k = state.fieldErrors?.[f];
    return k ? (t[k as keyof typeof t] as string) || t.required : null;
  };

  if (state.status === "success") {
    return (
      <div className="flex flex-col items-center rounded-[var(--radius-card)] bg-white p-10 text-center shadow-soft" role="status">
        <span className="grid size-16 place-items-center rounded-full bg-green-100 text-green-700">
          <CircleCheck className="size-8" />
        </span>
        <p className="mt-6 max-w-sm text-lg font-semibold">{t.success}</p>
      </div>
    );
  }

  const input = (name: string, label: string, type = "text", required = false, autoComplete?: string) => (
    <div>
      <label htmlFor={`f-${name}`} className="label">
        {label}
        {required && <span className="text-brand"> *</span>}
      </label>
      <input
        id={`f-${name}`}
        name={name}
        type={type}
        required={required}
        autoComplete={autoComplete}
        defaultValue={state.values?.[name]}
        aria-invalid={!!err(name)}
        aria-describedby={err(name) ? `e-${name}` : undefined}
        className="field !py-3 !text-base"
      />
      {err(name) && (
        <p id={`e-${name}`} className="mt-1 text-sm text-red-600">
          {err(name)}
        </p>
      )}
    </div>
  );

  return (
    <form key={state.ts} action={action} className="card relative space-y-5 p-6 sm:p-8">
      <input type="hidden" name="locale" value={locale} />
      <div className="absolute -left-[9999px]" aria-hidden="true">
        <label>
          Website <input type="text" name="company_website" tabIndex={-1} autoComplete="off" />
        </label>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        {input("name", t.name, "text", true, "name")}
        {input("email", t.email, "email", true, "email")}
        {input("phone", t.phone, "tel", false, "tel")}
        {input("postcode", t.postcode, "text", false, "postal-code")}
      </div>
      <div>
        <label htmlFor="f-service" className="label">
          {t.service}
        </label>
        <select id="f-service" name="service" className="field !py-3 !text-base" defaultValue={state.values?.service ?? ""}>
          <option value="">{t.servicePlaceholder}</option>
          {services.map((s) => (
            <option key={s.key} value={s.key}>
              {s.label}
            </option>
          ))}
          <option value="other">{t.other}</option>
        </select>
      </div>
      <div>
        <label htmlFor="f-message" className="label">
          {t.message}
          <span className="text-brand"> *</span>
        </label>
        <textarea
          id="f-message"
          name="message"
          rows={5}
          required
          placeholder={t.messagePlaceholder}
          defaultValue={state.values?.message}
          aria-invalid={!!err("message")}
          className="field !py-3 !text-base"
        />
        {err("message") && <p className="mt-1 text-sm text-red-600">{err("message")}</p>}
      </div>
      <label className="flex items-start gap-3 text-sm text-ink-700">
        <input type="checkbox" name="privacy" required defaultChecked={state.values?.privacy === "on"} className="mt-0.5 size-4 accent-brand" />
        <span>
          {t.privacy}{" "}
          <Link href={privacyHref} className="font-medium text-brand underline underline-offset-2" target="_blank">
            {t.privacyLink}
          </Link>
          .{err("privacy") && <span className="block text-red-600">{err("privacy")}</span>}
        </span>
      </label>
      {state.status === "error" && state.message && (
        <p className="flex items-center gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">
          <CircleAlert className="size-4" /> {state.message === "tooMany" ? t.tooMany : t.error}
        </p>
      )}
      <button type="submit" disabled={pending} className="btn-primary w-full !py-4 text-base">
        {pending ? <Loader2 className="size-5 animate-spin" /> : <Send className="size-4" />}
        {pending ? t.sending : t.submit}
      </button>
    </form>
  );
}
