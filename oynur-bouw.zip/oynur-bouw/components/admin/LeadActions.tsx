"use client";

import { useState, useTransition } from "react";
import { Loader2, MailOpen, Mail, Trash2 } from "lucide-react";
import { deleteLead, setLeadRead } from "@/app/admin/actions";

export function LeadActions({ id, read }: { id: string; read: boolean }) {
  const [pending, start] = useTransition();
  const [confirm, setConfirm] = useState(false);
  const btn = "inline-flex items-center gap-1.5 rounded-lg border border-line bg-white px-3 py-1.5 text-xs font-semibold text-stone hover:text-ink disabled:opacity-50";
  return (
    <div className="flex flex-wrap items-center gap-2">
      {pending && <Loader2 className="size-4 animate-spin text-stone" />}
      <button type="button" className={btn} disabled={pending} onClick={() => start(() => setLeadRead(id, !read))}>
        {read ? <Mail className="size-3.5" /> : <MailOpen className="size-3.5" />} {read ? "Mark unread" : "Mark as read"}
      </button>
      {confirm ? (
        <>
          <button type="button" className={`${btn} !border-red-200 !text-red-600`} disabled={pending} onClick={() => start(() => deleteLead(id))}>
            Confirm delete
          </button>
          <button type="button" className={btn} onClick={() => setConfirm(false)}>
            Cancel
          </button>
        </>
      ) : (
        <button type="button" className={btn} onClick={() => setConfirm(true)}>
          <Trash2 className="size-3.5" /> Delete
        </button>
      )}
    </div>
  );
}
