"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { FolderKanban, Inbox, LayoutDashboard, Settings } from "lucide-react";

const items = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/projects", label: "Portfolio", icon: FolderKanban },
  { href: "/admin/leads", label: "Requests", icon: Inbox },
  { href: "/admin/settings", label: "Settings", icon: Settings },
];

export function AdminNav({ unread }: { unread: number }) {
  const pathname = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto lg:flex-col">
      {items.map((it) => {
        const active = it.href === "/admin" ? pathname === "/admin" : pathname.startsWith(it.href);
        return (
          <Link
            key={it.href}
            href={it.href}
            className={`flex shrink-0 items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition ${
              active ? "bg-white/10 text-white" : "text-white/60 hover:bg-white/5 hover:text-white"
            }`}
          >
            <it.icon className={`size-[18px] ${active ? "text-brand" : ""}`} />
            {it.label}
            {it.href === "/admin/leads" && unread > 0 && (
              <span className="ml-auto rounded-full bg-brand px-2 py-0.5 text-xs font-bold text-white">{unread}</span>
            )}
          </Link>
        );
      })}
    </nav>
  );
}
