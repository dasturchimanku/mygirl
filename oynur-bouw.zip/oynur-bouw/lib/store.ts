import "server-only";
import { promises as fs } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import type { Database, Lead, Project, Settings } from "./types";
import { socialKeys } from "./types";

/**
 * Tiny file-based database.
 *
 * All content lives in `storage/db.json` and uploaded photos in `storage/uploads`.
 * This keeps the website dependency-free (no database server needed) and makes
 * backups trivial: copy the `storage` folder. Writes are serialized and atomic.
 */

export const STORAGE_DIR = path.resolve(/*turbopackIgnore: true*/ process.env.STORAGE_DIR || path.join(/*turbopackIgnore: true*/ process.cwd(), "storage"));
export const UPLOAD_DIR = path.join(STORAGE_DIR, "uploads");
const DB_FILE = path.join(STORAGE_DIR, "db.json");

const emptyL = () => ({ nl: "", en: "" });

export function defaultSettings(): Settings {
  return {
    companyName: "Oynur Bouw B.V.",
    tagline: {
      nl: "Renovatie en verbouw met vakmanschap",
      en: "Renovation and remodelling with craftsmanship",
    },
    phone: "",
    whatsapp: "",
    email: "",
    street: "",
    postalCode: "",
    city: "",
    country: "NL",
    kvk: "",
    btw: "",
    serviceArea: { nl: "Heel Nederland", en: "Throughout the Netherlands" },
    openingHours: { nl: "Ma – Vr: 08:00 – 18:00\nZa: op afspraak", en: "Mon – Fri: 08:00 – 18:00\nSat: by appointment" },
    socials: Object.fromEntries(socialKeys.map((k) => [k, ""])) as Settings["socials"],
    stats: { yearsExperience: "", projectsCompleted: "", rating: "" },
    heroImage: null,
    aboutImage: null,
    updatedAt: new Date().toISOString(),
  };
}

function emptyDb(): Database {
  return { version: 1, settings: defaultSettings(), projects: [], leads: [] };
}

/** Merge stored data onto defaults so new fields never break old databases. */
function normalize(raw: Partial<Database>): Database {
  const base = emptyDb();
  const s = { ...base.settings, ...(raw.settings || {}) } as Settings;
  s.socials = { ...base.settings.socials, ...(raw.settings?.socials || {}) };
  s.stats = { ...base.settings.stats, ...(raw.settings?.stats || {}) };
  const projects = (raw.projects || []).map((p) => ({
    ...{
      summary: emptyL(),
      description: emptyL(),
      duration: emptyL(),
      seoTitle: emptyL(),
      seoDescription: emptyL(),
      images: [],
      coverImageId: null,
      featured: false,
      published: false,
      order: 0,
      location: "",
      year: "",
    },
    ...p,
  })) as Project[];
  return { version: 1, settings: s, projects, leads: (raw.leads || []) as Lead[] };
}

let cache: { mtimeMs: number; db: Database } | null = null;

export async function readDb(): Promise<Database> {
  try {
    const stat = await fs.stat(DB_FILE);
    if (cache && cache.mtimeMs === stat.mtimeMs) return structuredClone(cache.db);
    const text = await fs.readFile(DB_FILE, "utf8");
    const db = normalize(JSON.parse(text));
    cache = { mtimeMs: stat.mtimeMs, db };
    return structuredClone(db);
  } catch (err: unknown) {
    if ((err as NodeJS.ErrnoException).code === "ENOENT") {
      const db = emptyDb();
      await writeFileAtomic(db);
      return db;
    }
    throw err;
  }
}

async function writeFileAtomic(db: Database) {
  await fs.mkdir(STORAGE_DIR, { recursive: true });
  const tmp = `${DB_FILE}.${process.pid}.${Date.now()}.tmp`;
  const data = JSON.stringify(db, null, 2);
  await fs.writeFile(tmp, data, "utf8");
  try {
    await fs.rename(tmp, DB_FILE);
  } catch {
    // Windows can refuse to replace a file that is briefly locked (antivirus, indexer).
    await fs.writeFile(DB_FILE, data, "utf8");
    await fs.rm(tmp, { force: true });
  }
  cache = null;
}

let queue: Promise<unknown> = Promise.resolve();

/** Serialized read-modify-write. */
export function updateDb<T>(fn: (db: Database) => T | Promise<T>): Promise<T> {
  const run = queue.then(async () => {
    const db = await readDb();
    const result = await fn(db);
    await writeFileAtomic(db);
    return result;
  });
  queue = run.catch(() => undefined);
  return run;
}

export function newId(bytes = 8) {
  return crypto.randomBytes(bytes).toString("hex");
}

/* ── Query helpers ─────────────────────────────────────────── */

export async function getSettings() {
  return (await readDb()).settings;
}

function sortProjects(a: Project, b: Project) {
  return a.order - b.order || b.createdAt.localeCompare(a.createdAt);
}

export async function getPublishedProjects() {
  return (await readDb()).projects.filter((p) => p.published).sort(sortProjects);
}

export async function getAllProjects() {
  return (await readDb()).projects.sort(sortProjects);
}

export async function getProjectBySlug(slug: string) {
  return (await readDb()).projects.find((p) => p.slug === slug) || null;
}

export async function getProjectById(id: string) {
  return (await readDb()).projects.find((p) => p.id === id) || null;
}

export async function getLeads() {
  return (await readDb()).leads.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function deleteUpload(src: string) {
  if (!src.startsWith("/media/")) return;
  const file = path.basename(src);
  await fs.rm(path.join(UPLOAD_DIR, file), { force: true }).catch(() => undefined);
}
