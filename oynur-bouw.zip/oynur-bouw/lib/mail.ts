import "server-only";
import nodemailer from "nodemailer";
import type { Lead, Settings } from "./types";
import { getService } from "./services";
import { siteUrl } from "./site";

/** Sends an e-mail about a new request if SMTP is configured in .env.local. */
export async function sendLeadNotification(lead: Lead, settings: Settings) {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM, NOTIFY_EMAIL } = process.env;
  const to = NOTIFY_EMAIL || settings.email;
  if (!SMTP_HOST || !to) return;
  const port = Number(SMTP_PORT || 587);
  const transport = nodemailer.createTransport({
    host: SMTP_HOST,
    port,
    secure: port === 465,
    auth: SMTP_USER ? { user: SMTP_USER, pass: SMTP_PASSWORD } : undefined,
  });
  const service = getService(lead.service)?.title.nl || lead.service || "-";
  const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
  const rows: [string, string][] = [
    ["Naam", lead.name],
    ["E-mail", lead.email],
    ["Telefoon", lead.phone || "-"],
    ["Postcode", lead.postcode || "-"],
    ["Dienst", service],
  ];
  await transport.sendMail({
    from: SMTP_FROM || SMTP_USER || to,
    to,
    replyTo: lead.email,
    subject: `Nieuwe aanvraag via website: ${lead.name} (${service})`,
    text: `${rows.map(([k, v]) => `${k}: ${v}`).join("\n")}\n\n${lead.message}\n\nBekijk in admin: ${siteUrl}/admin/leads`,
    html: `<h2>Nieuwe aanvraag via de website</h2><table>${rows
      .map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#666">${k}</td><td><strong>${esc(v)}</strong></td></tr>`)
      .join("")}</table><p style="white-space:pre-line;border-left:3px solid #FC5000;padding-left:12px">${esc(lead.message)}</p><p><a href="${siteUrl}/admin/leads">Bekijk in admin</a></p>`,
  });
}
