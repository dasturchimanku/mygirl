export const locales = ["nl", "en"] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = "nl";

export type Localized = { nl: string; en: string };

export type ImageKind = "gallery" | "before" | "after";

export type ProjectImage = {
  id: string;
  src: string; // e.g. /media/abc123.webp
  width: number;
  height: number;
  alt: Localized;
  kind: ImageKind;
};

export type Project = {
  id: string;
  slug: string;
  title: Localized;
  summary: Localized;
  description: Localized;
  category: string; // service key
  location: string;
  year: string;
  duration: Localized;
  images: ProjectImage[];
  coverImageId: string | null;
  published: boolean;
  featured: boolean;
  order: number;
  seoTitle: Localized;
  seoDescription: Localized;
  createdAt: string;
  updatedAt: string;
};

export type Lead = {
  id: string;
  name: string;
  email: string;
  phone: string;
  postcode: string;
  service: string;
  message: string;
  locale: Locale;
  createdAt: string;
  read: boolean;
};

export const socialKeys = [
  "instagram",
  "tiktok",
  "facebook",
  "linkedin",
  "youtube",
  "pinterest",
  "x",
  "google",
  "werkspot",
] as const;
export type SocialKey = (typeof socialKeys)[number];

export type Settings = {
  companyName: string;
  tagline: Localized;
  phone: string;
  whatsapp: string;
  email: string;
  street: string;
  postalCode: string;
  city: string;
  country: string;
  kvk: string;
  btw: string;
  serviceArea: Localized;
  openingHours: Localized;
  socials: Record<SocialKey, string>;
  stats: {
    yearsExperience: string;
    projectsCompleted: string;
    rating: string;
  };
  heroImage: ProjectImage | null;
  aboutImage: ProjectImage | null;
  updatedAt: string;
};

export type Database = {
  version: 1;
  settings: Settings;
  projects: Project[];
  leads: Lead[];
};
