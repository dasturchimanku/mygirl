import Image from "next/image";
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { LoginForm } from "./LoginForm";

export const metadata = { title: "Log in" };

export default async function LoginPage() {
  if (await getSession().catch(() => null)) redirect("/admin");
  return (
    <div className="grid min-h-dvh lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-ink lg:block">
        <div className="blueprint absolute inset-0" />
        <div className="absolute -right-32 -bottom-32 size-[520px] rounded-full border-[80px] border-brand" />
        <div className="relative p-12">
          <Image src="/brand/logo-white.png" alt="Oynur Bouw B.V." width={220} height={44} className="h-9 w-auto" />
          <p className="mt-16 max-w-sm font-display text-4xl leading-tight font-extrabold text-white">
            Manage your projects, requests and company details.
          </p>
        </div>
      </div>
      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-sm">
          <Image src="/brand/logo.png" alt="Oynur Bouw B.V." width={200} height={40} className="mb-10 h-8 w-auto lg:hidden" />
          <h1 className="text-3xl font-extrabold">Log in</h1>
          <p className="mt-2 mb-8 text-stone">Sign in to the website admin panel.</p>
          <LoginForm />
        </div>
      </div>
    </div>
  );
}
