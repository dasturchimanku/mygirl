import { Inbox, Mail, MapPin, Phone } from "lucide-react";
import { getLeads } from "@/lib/store";
import { getService } from "@/lib/services";
import { telHref, whatsappHref } from "@/lib/site";
import { PageHeader } from "@/components/admin/PageHeader";
import { LeadActions } from "@/components/admin/LeadActions";
import { SocialIcon } from "@/components/SocialIcon";

export const metadata = { title: "Requests" };

export default async function LeadsPage() {
  const leads = await getLeads();
  const unread = leads.filter((l) => !l.read).length;
  return (
    <>
      <PageHeader title="Requests" text={`Quote requests and messages from the contact form · ${unread} unread`} />
      {leads.length === 0 ? (
        <div className="card flex flex-col items-center p-12 text-center">
          <span className="grid size-16 place-items-center rounded-2xl bg-brand-50 text-brand">
            <Inbox className="size-8" />
          </span>
          <h2 className="mt-5 text-xl font-bold">No requests yet</h2>
          <p className="mt-1 max-w-sm text-stone">When someone fills in the contact form on your website, it shows up here.</p>
        </div>
      ) : (
        <ul className="space-y-4">
          {leads.map((l) => (
            <li key={l.id} id={l.id} className={`card scroll-mt-6 p-6 ${l.read ? "" : "ring-2 ring-brand/60"}`}>
              <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    {!l.read && <span className="rounded-full bg-brand px-2 py-0.5 text-xs font-bold text-white">New</span>}
                    <h2 className="text-lg font-bold">{l.name}</h2>
                    <span className="rounded-full bg-sand px-2 py-0.5 text-xs font-medium text-stone uppercase">{l.locale}</span>
                  </div>
                  <p className="mt-0.5 text-sm text-stone">
                    {new Date(l.createdAt).toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Amsterdam" })}
                    {l.service && ` · ${getService(l.service)?.title.en || (l.service === "other" ? "Other" : l.service)}`}
                  </p>
                </div>
                <LeadActions id={l.id} read={l.read} />
              </div>
              <p className="mt-4 rounded-xl bg-sand/50 p-4 whitespace-pre-line text-ink-700">{l.message}</p>
              <div className="mt-4 flex flex-wrap gap-2 text-sm">
                <a href={`mailto:${l.email}?subject=${encodeURIComponent("Uw aanvraag bij Oynur Bouw")}`} className="btn-dark !px-4 !py-2 !text-xs">
                  <Mail className="size-3.5" /> {l.email}
                </a>
                {l.phone && (
                  <>
                    <a href={telHref(l.phone)} className="btn-ghost !px-4 !py-2 !text-xs">
                      <Phone className="size-3.5" /> {l.phone}
                    </a>
                    <a href={whatsappHref(l.phone)} target="_blank" rel="noopener noreferrer" className="btn-ghost !px-4 !py-2 !text-xs">
                      <SocialIcon name="whatsapp" className="size-3.5" /> WhatsApp
                    </a>
                  </>
                )}
                {l.postcode && (
                  <span className="inline-flex items-center gap-1.5 px-2 text-stone">
                    <MapPin className="size-3.5" /> {l.postcode}
                  </span>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
