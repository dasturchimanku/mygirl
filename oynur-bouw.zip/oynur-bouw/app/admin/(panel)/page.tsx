import Link from "next/link";
import { ArrowRight, CircleCheck, Circle, FolderKanban, Image as ImageIcon, Inbox, Plus, EyeOff } from "lucide-react";
import { getAllProjects, getLeads, getSettings } from "@/lib/store";
import { siteUrl } from "@/lib/site";
import { getService } from "@/lib/services";
import { PageHeader } from "@/components/admin/PageHeader";

export const metadata = { title: "Dashboard" };

export default async function Dashboard() {
  const [projects, leads, s] = await Promise.all([getAllProjects(), getLeads(), getSettings()]);
  const published = projects.filter((p) => p.published).length;
  const photos = projects.reduce((n, p) => n + p.images.length, 0);
  const unread = leads.filter((l) => !l.read).length;
  const socials = Object.values(s.socials).filter(Boolean).length;

  const checklist = [
    { done: !!s.phone && !!s.email, label: "Add phone number and email", href: "/admin/settings" },
    { done: socials > 0, label: `Add your social media profiles (${socials} added)`, href: "/admin/settings#socials" },
    { done: !!s.city, label: "Add company address", href: "/admin/settings" },
    { done: !!s.kvk, label: "Add KvK number", href: "/admin/settings" },
    { done: !!s.heroImage, label: "Upload a homepage photo", href: "/admin/settings#images" },
    { done: published > 0, label: "Publish your first portfolio project", href: "/admin/projects/new" },
    { done: !siteUrl.includes("localhost"), label: "Set NEXT_PUBLIC_SITE_URL to your domain in .env.local", href: null },
  ];
  const todo = checklist.filter((c) => !c.done).length;

  const stats = [
    { label: "Published projects", value: published, icon: FolderKanban, href: "/admin/projects" },
    { label: "Drafts", value: projects.length - published, icon: EyeOff, href: "/admin/projects" },
    { label: "Photos", value: photos, icon: ImageIcon, href: "/admin/projects" },
    { label: "Unread requests", value: unread, icon: Inbox, href: "/admin/leads", highlight: unread > 0 },
  ];

  return (
    <>
      <PageHeader
        title="Welcome back 👋"
        text="Manage your portfolio, incoming requests and company details."
        actions={
          <Link href="/admin/projects/new" className="btn-primary">
            <Plus className="size-4" /> New project
          </Link>
        }
      />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((st) => (
          <Link key={st.label} href={st.href} className={`card p-5 transition hover:shadow-lift ${st.highlight ? "ring-2 ring-brand" : ""}`}>
            <st.icon className="size-5 text-brand" />
            <p className="mt-4 font-display text-3xl font-extrabold">{st.value}</p>
            <p className="text-sm text-stone">{st.label}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <section className="card p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold">Latest requests</h2>
            <Link href="/admin/leads" className="text-sm font-semibold text-brand">
              View all
            </Link>
          </div>
          {leads.length === 0 ? (
            <p className="mt-6 text-sm text-stone">No requests yet. Submissions from the contact form will appear here.</p>
          ) : (
            <ul className="mt-4 divide-y divide-line">
              {leads.slice(0, 6).map((l) => (
                <li key={l.id}>
                  <Link href={`/admin/leads#${l.id}`} className="flex items-center gap-3 py-3">
                    <span className={`size-2 shrink-0 rounded-full ${l.read ? "bg-line" : "bg-brand"}`} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate font-medium">{l.name}</span>
                      <span className="block truncate text-sm text-stone">
                        {getService(l.service)?.title.en || l.service || "—"} · {l.message}
                      </span>
                    </span>
                    <span className="shrink-0 text-xs text-stone">{new Date(l.createdAt).toLocaleDateString("en-GB")}</span>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card p-6">
          <h2 className="text-lg font-bold">Website checklist</h2>
          <p className="text-sm text-stone">{todo === 0 ? "Everything is set up. Great job!" : `${todo} item(s) left to complete`}</p>
          <ul className="mt-4 space-y-1">
            {checklist.map((c) => {
              const inner = (
                <>
                  {c.done ? <CircleCheck className="size-5 shrink-0 text-green-600" /> : <Circle className="size-5 shrink-0 text-line" />}
                  <span className={`flex-1 ${c.done ? "text-stone line-through" : ""}`}>{c.label}</span>
                  {!c.done && c.href && <ArrowRight className="size-4 text-stone" />}
                </>
              );
              return (
                <li key={c.label}>
                  {c.href && !c.done ? (
                    <Link href={c.href} className="flex items-center gap-3 rounded-lg px-2 py-2 text-sm hover:bg-sand/60">
                      {inner}
                    </Link>
                  ) : (
                    <div className="flex items-center gap-3 px-2 py-2 text-sm">{inner}</div>
                  )}
                </li>
              );
            })}
          </ul>
        </section>
      </div>
    </>
  );
}
