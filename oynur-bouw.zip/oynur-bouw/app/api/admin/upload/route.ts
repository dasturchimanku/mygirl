import { NextResponse } from "next/server";
import { promises as fs } from "node:fs";
import path from "node:path";
import sharp from "sharp";
import { getSession } from "@/lib/auth";
import { UPLOAD_DIR, newId } from "@/lib/store";

export const runtime = "nodejs";

const MAX_BYTES = 30 * 1024 * 1024; // 30 MB per photo

export async function POST(req: Request) {
  if (!(await getSession())) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!file || typeof file === "string") return NextResponse.json({ error: "No file" }, { status: 400 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "File too large (max 30 MB)" }, { status: 413 });
  if (!/^image\//.test(file.type) && !/\.(jpe?g|png|webp|avif|heic|heif)$/i.test(file.name)) {
    return NextResponse.json({ error: "Only images are allowed" }, { status: 415 });
  }

  try {
    const input = Buffer.from(await file.arrayBuffer());
    const { data, info } = await sharp(input, { failOn: "none" })
      .rotate() // respect EXIF orientation from phones
      .resize({ width: 2400, height: 2400, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer({ resolveWithObject: true });

    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    const name = `${newId(10)}.webp`;
    await fs.writeFile(path.join(UPLOAD_DIR, name), data);

    const base = file.name.replace(/\.[^.]+$/, "").replace(/[-_]+/g, " ").trim();
    return NextResponse.json({
      id: newId(),
      src: `/media/${name}`,
      width: info.width,
      height: info.height,
      alt: { nl: "", en: "" },
      kind: "gallery",
      originalName: base,
    });
  } catch (e) {
    console.error("Upload failed", e);
    return NextResponse.json({ error: "Could not process this image" }, { status: 422 });
  }
}
