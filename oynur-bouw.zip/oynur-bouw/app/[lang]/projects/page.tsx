import type { Metadata } from "next";
import type { Locale } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { pagePath } from "@/lib/routes";
import { buildMetadata, samePaths } from "@/lib/seo";
import { getPublishedProjects, getSettings } from "@/lib/store";
import { services } from "@/lib/services";
import { absoluteUrl } from "@/lib/site";
import { coverOf } from "@/lib/projects";
import { projectPath } from "@/lib/routes";
import { PageHero } from "@/components/site/PageHero";
import { ProjectCard } from "@/components/site/ProjectCard";
import { ProjectFilter } from "@/components/site/ProjectFilter";
import { CtaBanner } from "@/components/site/CtaBanner";
import { SocialLinks } from "@/components/site/SocialLinks";
import { JsonLd } from "@/components/JsonLd";

type Props = { params: Promise<{ lang: Locale }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;
  const t = getDictionary(lang);
  const projects = await getPublishedProjects();
  const cover = projects.map(coverOf).find(Boolean);
  return buildMetadata({
    locale: lang,
    title: t.projects.metaTitle,
    description: t.projects.metaDescription,
    paths: samePaths((l) => pagePath(l, "projects")),
    ...(cover ? { images: [{ url: cover.src, width: cover.width, height: cover.height, alt: cover.alt[lang] }] } : {}),
  });
}

export default async function ProjectsPage({ params }: Props) {
  const { lang } = await params;
  const t = getDictionary(lang);
  const [projects, settings] = await Promise.all([getPublishedProjects(), getSettings()]);
  const categories = services
    .map((s) => ({ key: s.key, label: s.title[lang], count: projects.filter((p) => p.category === s.key).length }))
    .filter((c) => c.count > 0);

  const listLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: projects.map((p, i) => ({
      "@type": "ListItem",
      position: i + 1,
      url: absoluteUrl(projectPath(lang, p.slug)),
      name: p.title[lang] || p.title.nl,
    })),
  };

  return (
    <>
      {projects.length > 0 && <JsonLd data={listLd} />}
      <PageHero
        eyebrow={t.home.projectsEyebrow}
        title={t.projects.title}
        text={t.projects.text}
        crumbs={[
          { name: t.breadcrumbs.home, path: pagePath(lang, "home") },
          { name: t.nav.projects, path: pagePath(lang, "projects") },
        ]}
      />
      <section className="container-x py-16 lg:py-24">
        {projects.length === 0 ? (
          <div className="mx-auto max-w-xl rounded-[var(--radius-card)] border border-dashed border-line bg-white p-10 text-center">
            <p className="text-lg text-stone">{t.projects.empty}</p>
            <div className="mt-6 flex justify-center">
              <SocialLinks settings={settings} variant="light" size="lg" />
            </div>
          </div>
        ) : (
          <ProjectFilter categories={categories} allLabel={t.projects.all}>
            <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((p, i) => (
                <li key={p.id} data-category={p.category}>
                  <ProjectCard project={p} locale={lang} priority={i < 3} />
                </li>
              ))}
            </ul>
          </ProjectFilter>
        )}
      </section>
      <CtaBanner locale={lang} settings={settings} />
    </>
  );
}
