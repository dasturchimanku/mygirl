import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, Calendar, MapPin, Tag, Timer } from "lucide-react";
import type { Locale } from "@/lib/types";
import { locales } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { getProjectBySlug, getPublishedProjects, getSettings } from "@/lib/store";
import { getService } from "@/lib/services";
import { pagePath, projectPath, servicePath } from "@/lib/routes";
import { buildMetadata, samePaths } from "@/lib/seo";
import { absoluteUrl, siteUrl } from "@/lib/site";
import { coverOf } from "@/lib/projects";
import { Breadcrumbs } from "@/components/site/Breadcrumbs";
import { Gallery } from "@/components/site/Gallery";
import { BeforeAfter } from "@/components/site/BeforeAfter";
import { CtaBanner } from "@/components/site/CtaBanner";
import { JsonLd } from "@/components/JsonLd";

type Props = { params: Promise<{ lang: Locale; slug: string }> };

export async function generateStaticParams() {
  const projects = await getPublishedProjects();
  return locales.flatMap((lang) => projects.map((p) => ({ lang, slug: p.slug })));
}

async function load(slug: string) {
  const p = await getProjectBySlug(slug);
  return p && p.published ? p : null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang, slug } = await params;
  const p = await load(slug);
  if (!p) return {};
  const title = p.seoTitle[lang] || p.title[lang] || p.title.nl;
  const description = (p.seoDescription[lang] || p.summary[lang] || p.summary.nl || p.description[lang] || "").slice(0, 160);
  const cover = coverOf(p);
  return buildMetadata({
    locale: lang,
    title,
    description,
    type: "article",
    paths: samePaths((l) => projectPath(l, p.slug)),
    ...(cover ? { images: [{ url: cover.src, width: cover.width, height: cover.height, alt: cover.alt[lang] || title }] } : {}),
  });
}

function paragraphs(text: string) {
  return text
    .split(/\n\s*\n/)
    .map((s) => s.trim())
    .filter(Boolean);
}

export default async function ProjectPage({ params }: Props) {
  const { lang, slug } = await params;
  const project = await load(slug);
  if (!project) notFound();
  const t = getDictionary(lang);
  const [settings, all] = await Promise.all([getSettings(), getPublishedProjects()]);
  const service = getService(project.category);
  const title = project.title[lang] || project.title.nl;
  const summary = project.summary[lang] || project.summary.nl;
  const description = project.description[lang] || project.description.nl;
  const cover = coverOf(project);
  const alt = (i: { alt: { nl: string; en: string } }) => i.alt[lang] || i.alt.nl || title;

  const befores = project.images.filter((i) => i.kind === "before");
  const afters = project.images.filter((i) => i.kind === "after");
  const pairs = befores.slice(0, afters.length).map((b, i) => ({ before: b, after: afters[i] }));
  const paired = new Set(pairs.flatMap((p) => [p.before.id, p.after.id]));
  const gallery = project.images.filter((i) => !paired.has(i.id) && i.id !== cover?.id);
  const galleryAll = cover && !paired.has(cover.id) ? [cover, ...gallery] : gallery;

  const idx = all.findIndex((p) => p.id === project.id);
  const next = all.length > 1 ? all[(idx + 1) % all.length] : null;

  const meta = [
    project.location && { icon: MapPin, label: t.projects.location, value: project.location },
    project.year && { icon: Calendar, label: t.projects.year, value: project.year },
    (project.duration[lang] || project.duration.nl) && { icon: Timer, label: t.projects.duration, value: project.duration[lang] || project.duration.nl },
    service && { icon: Tag, label: t.projects.category, value: service.title[lang], href: servicePath(lang, service.key) },
  ].filter(Boolean) as { icon: typeof MapPin; label: string; value: string; href?: string }[];

  const ld = {
    "@context": "https://schema.org",
    "@type": "CreativeWork",
    name: title,
    headline: title,
    description: summary || description.slice(0, 200),
    url: absoluteUrl(projectPath(lang, project.slug)),
    image: project.images.map((i) => absoluteUrl(i.src)),
    inLanguage: lang === "nl" ? "nl-NL" : "en",
    dateCreated: project.year || undefined,
    dateModified: project.updatedAt,
    ...(project.location ? { locationCreated: { "@type": "Place", name: project.location } } : {}),
    ...(service ? { genre: service.title[lang], about: service.title[lang] } : {}),
    creator: { "@id": `${siteUrl}/#organization` },
  };

  return (
    <>
      <JsonLd data={ld} />
      <section className="relative isolate overflow-hidden bg-ink pt-28 text-white lg:pt-36">
        {cover && (
          <>
            <Image src={cover.src} alt="" fill priority sizes="100vw" className="-z-20 object-cover opacity-35" />
            <div className="absolute inset-0 -z-10 bg-gradient-to-t from-ink via-ink/70 to-ink/40" aria-hidden="true" />
          </>
        )}
        <div className="container-x pb-14 lg:pb-20">
          <Breadcrumbs
            dark
            items={[
              { name: t.breadcrumbs.home, path: pagePath(lang, "home") },
              { name: t.nav.projects, path: pagePath(lang, "projects") },
              { name: title, path: projectPath(lang, project.slug) },
            ]}
          />
          {service && <p className="eyebrow mt-8">{service.title[lang]}</p>}
          <h1 className="mt-4 max-w-4xl text-4xl leading-[1.05] font-extrabold sm:text-5xl lg:text-6xl">{title}</h1>
          {summary && <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/75">{summary}</p>}
          {meta.length > 0 && (
            <dl className={`mt-10 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-2xl bg-white/10 ${["sm:grid-cols-1", "sm:grid-cols-2", "sm:grid-cols-3", "sm:grid-cols-4"][meta.length - 1]}`}>
              {meta.map((m) => (
                <div key={m.label} className="bg-ink/60 p-4 backdrop-blur">
                  <dt className="flex items-center gap-1.5 text-xs text-white/55 uppercase">
                    <m.icon className="size-3.5 text-brand" /> {m.label}
                  </dt>
                  <dd className="mt-1 font-semibold">
                    {m.href ? (
                      <Link href={m.href} className="hover:text-brand">
                        {m.value}
                      </Link>
                    ) : (
                      m.value
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          )}
        </div>
      </section>

      {description && (
        <section className="container-x py-16 lg:py-20">
          <div className="prose-ob max-w-3xl text-lg">
            {paragraphs(description).map((p) => (
              <p key={p.slice(0, 40)} className="whitespace-pre-line">
                {p}
              </p>
            ))}
          </div>
        </section>
      )}

      {pairs.length > 0 && (
        <section className="container-x pb-16">
          <h2 className="mb-8 text-2xl font-extrabold sm:text-3xl">{t.projects.beforeAfter}</h2>
          <div className="grid gap-8 lg:grid-cols-2">
            {pairs.map((p) => (
              <BeforeAfter
                key={p.before.id}
                before={{ ...p.before, alt: alt(p.before) }}
                after={{ ...p.after, alt: alt(p.after) }}
                labels={{ before: t.projects.before, after: t.projects.after }}
              />
            ))}
          </div>
        </section>
      )}

      {galleryAll.length > 0 && (
        <section className={`container-x ${description || pairs.length ? "pb-16" : "py-16"}`}>
          <h2 className="mb-8 text-2xl font-extrabold sm:text-3xl">{t.projects.gallery}</h2>
          <Gallery
            images={galleryAll.map((i) => ({ src: i.src, width: i.width, height: i.height, alt: alt(i) }))}
            labels={{ close: t.nav.close, photoOf: t.projects.photoOf }}
          />
        </section>
      )}

      <section className="container-x">
        <div className="flex flex-col justify-between gap-4 border-t border-line pt-8 sm:flex-row">
          <Link href={pagePath(lang, "projects")} className="btn-ghost">
            <ArrowLeft className="size-4" /> {t.projects.back}
          </Link>
          {next && next.id !== project.id && (
            <Link href={projectPath(lang, next.slug)} className="btn-dark">
              {t.projects.next}: {next.title[lang] || next.title.nl} <ArrowRight className="size-4" />
            </Link>
          )}
        </div>
      </section>

      <CtaBanner locale={lang} settings={settings} />
    </>
  );
}
