"use server";

import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { newId, updateDb, getSettings } from "@/lib/store";
import { rateLimit } from "@/lib/auth";
import { isLocale } from "@/lib/i18n";
import { sendLeadNotification } from "@/lib/mail";

export type ContactState = {
  status: "idle" | "success" | "error";
  message?: string;
  fieldErrors?: Record<string, string>;
  /** Echo of the submitted values so the form keeps them after an error. */
  values?: Record<string, string>;
  ts?: number;
};

const schema = z.object({
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(200),
  phone: z.string().trim().max(40).optional().default(""),
  postcode: z.string().trim().max(12).optional().default(""),
  service: z.string().trim().max(60).optional().default(""),
  message: z.string().trim().min(5).max(5000),
  locale: z.string(),
});

export async function submitContact(_prev: ContactState, formData: FormData): Promise<ContactState> {
  // Honeypot: bots fill every field.
  if (formData.get("company_website")) return { status: "success" };

  const values = Object.fromEntries(
    ["name", "email", "phone", "postcode", "service", "message", "privacy"].map((k) => [k, String(formData.get(k) || "").slice(0, 5000)]),
  );
  const ts = Date.now();
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0].trim() || h.get("x-real-ip") || "local";
  if (!rateLimit(`contact:${ip}`, 5, 10 * 60 * 1000)) return { status: "error", message: "tooMany", values, ts };

  const parsed = schema.safeParse(Object.fromEntries(formData));
  if (!parsed.success || formData.get("privacy") !== "on") {
    const fieldErrors: Record<string, string> = {};
    parsed.error?.issues.forEach((i) => (fieldErrors[String(i.path[0])] = i.path[0] === "email" ? "invalidEmail" : "required"));
    if (formData.get("privacy") !== "on") fieldErrors.privacy = "required";
    return { status: "error", fieldErrors, values, ts };
  }
  const d = parsed.data;
  const lead = {
    id: newId(),
    name: d.name,
    email: d.email,
    phone: d.phone,
    postcode: d.postcode.toUpperCase(),
    service: d.service,
    message: d.message,
    locale: isLocale(d.locale) ? d.locale : "nl",
    createdAt: new Date().toISOString(),
    read: false,
  } as const;

  try {
    await updateDb((db) => {
      db.leads.push({ ...lead });
    });
  } catch (e) {
    console.error("Could not save lead", e);
    return { status: "error", message: "error", values, ts };
  }
  revalidatePath("/admin", "layout");

  const settings = await getSettings();
  sendLeadNotification({ ...lead }, settings).catch((e) => console.error("Lead e-mail failed", e));
  return { status: "success" };
}
