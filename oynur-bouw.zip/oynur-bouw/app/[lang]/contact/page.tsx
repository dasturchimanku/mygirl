import type { Metadata } from "next";
import { Clock, Mail, MapPin, Phone } from "lucide-react";
import type { Locale } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { pagePath } from "@/lib/routes";
import { buildMetadata, samePaths } from "@/lib/seo";
import { getSettings } from "@/lib/store";
import { services } from "@/lib/services";
import { telHref, whatsappHref } from "@/lib/site";
import { PageHero } from "@/components/site/PageHero";
import { ContactForm } from "@/components/site/ContactForm";
import { SocialLinks } from "@/components/site/SocialLinks";
import { SocialIcon } from "@/components/SocialIcon";

type Props = { params: Promise<{ lang: Locale }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;
  const t = getDictionary(lang);
  return buildMetadata({
    locale: lang,
    title: t.contact.metaTitle,
    description: t.contact.metaDescription,
    paths: samePaths((l) => pagePath(l, "contact")),
  });
}

export default async function ContactPage({ params }: Props) {
  const { lang } = await params;
  const t = getDictionary(lang);
  const s = await getSettings();
  const address = [s.street, [s.postalCode, s.city].filter(Boolean).join(" ")].filter(Boolean);
  const mapQuery = address.length ? encodeURIComponent(`${s.companyName}, ${address.join(", ")}`) : "";

  return (
    <>
      <PageHero
        eyebrow={t.nav.contact}
        title={t.contact.title}
        text={t.contact.text}
        crumbs={[
          { name: t.breadcrumbs.home, path: pagePath(lang, "home") },
          { name: t.nav.contact, path: pagePath(lang, "contact") },
        ]}
      />
      <section className="container-x grid gap-10 py-16 lg:grid-cols-[1.35fr_1fr] lg:gap-14 lg:py-24">
        <div className="lg:-mt-40 lg:relative lg:z-10">
          <ContactForm
            locale={lang}
            t={t.contact.form}
            services={services.map((sv) => ({ key: sv.key, label: sv.title[lang] }))}
            privacyHref={pagePath(lang, "privacy")}
          />
        </div>
        <aside className="space-y-8">
          <div>
            <h2 className="text-xl font-bold">{t.contact.details}</h2>
            <ul className="mt-5 space-y-3">
              {s.phone && (
                <li>
                  <a href={telHref(s.phone)} className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-4 transition hover:border-brand/40">
                    <span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand group-hover:bg-brand group-hover:text-white">
                      <Phone className="size-5" />
                    </span>
                    <span className="font-semibold">{s.phone}</span>
                  </a>
                </li>
              )}
              {s.whatsapp && (
                <li>
                  <a href={whatsappHref(s.whatsapp)} target="_blank" rel="noopener noreferrer" className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-4 transition hover:border-brand/40">
                    <span className="grid size-11 place-items-center rounded-xl bg-[#25D366]/10 text-[#1da851] group-hover:bg-[#25D366] group-hover:text-white">
                      <SocialIcon name="whatsapp" className="size-5" />
                    </span>
                    <span className="font-semibold">{t.cta.whatsapp}</span>
                  </a>
                </li>
              )}
              {s.email && (
                <li>
                  <a href={`mailto:${s.email}`} className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-4 transition hover:border-brand/40">
                    <span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand group-hover:bg-brand group-hover:text-white">
                      <Mail className="size-5" />
                    </span>
                    <span className="font-semibold break-all">{s.email}</span>
                  </a>
                </li>
              )}
              {address.length > 0 && (
                <li>
                  <a
                    href={`https://www.google.com/maps/search/?api=1&query=${mapQuery}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group flex items-center gap-4 rounded-2xl border border-line bg-white p-4 transition hover:border-brand/40"
                  >
                    <span className="grid size-11 place-items-center rounded-xl bg-brand-50 text-brand group-hover:bg-brand group-hover:text-white">
                      <MapPin className="size-5" />
                    </span>
                    <address className="font-semibold not-italic">{address.join(", ")}</address>
                  </a>
                </li>
              )}
            </ul>
          </div>
          {s.openingHours[lang] && (
            <div>
              <h2 className="flex items-center gap-2 text-xl font-bold">
                <Clock className="size-5 text-brand" /> {t.contact.hours}
              </h2>
              <p className="mt-3 whitespace-pre-line text-ink-700">{s.openingHours[lang]}</p>
            </div>
          )}
          {s.serviceArea[lang] && (
            <div>
              <h2 className="flex items-center gap-2 text-xl font-bold">
                <MapPin className="size-5 text-brand" /> {t.contact.area}
              </h2>
              <p className="mt-3 text-ink-700">{s.serviceArea[lang]}</p>
            </div>
          )}
          <div>
            <h2 className="text-xl font-bold">{t.contact.follow}</h2>
            <div className="mt-4">
              <SocialLinks settings={s} variant="light" size="lg" />
            </div>
          </div>
        </aside>
      </section>
      {mapQuery && (
        <section className="container-x pb-20">
          <div className="overflow-hidden rounded-[var(--radius-card)] border border-line">
            <iframe
              title="Google Maps"
              src={`https://maps.google.com/maps?q=${mapQuery}&output=embed`}
              className="h-[380px] w-full grayscale-[40%]"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </section>
      )}
    </>
  );
}
