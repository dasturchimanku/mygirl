import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Check } from "lucide-react";
import { getDictionary } from "@/lib/i18n";
import type { Locale } from "@/lib/types";
import { getPublishedProjects, getSettings } from "@/lib/store";
import { services } from "@/lib/services";
import { pagePath, servicePath } from "@/lib/routes";
import { buildMetadata, samePaths } from "@/lib/seo";
import { ServiceIcon } from "@/components/site/ServiceIcon";
import { ProjectCard } from "@/components/site/ProjectCard";
import { CtaBanner } from "@/components/site/CtaBanner";
import { SocialFollow } from "@/components/site/SocialFollow";

type Props = { params: Promise<{ lang: Locale }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;
  const t = getDictionary(lang);
  return buildMetadata({
    locale: lang,
    title: `Oynur Bouw B.V. | ${t.home.metaTitle}`,
    absoluteTitle: true,
    description: t.home.metaDescription,
    paths: samePaths((l) => pagePath(l, "home")),
  });
}

export default async function HomePage({ params }: Props) {
  const { lang } = await params;
  const t = getDictionary(lang);
  const [settings, projects] = await Promise.all([getSettings(), getPublishedProjects()]);
  const featured = [...projects.filter((p) => p.featured), ...projects.filter((p) => !p.featured)].slice(0, 6);
  const stats = [
    { v: settings.stats.yearsExperience, l: t.home.stats.years },
    { v: settings.stats.projectsCompleted, l: t.home.stats.projects },
    { v: settings.stats.rating, l: t.home.stats.rating },
  ].filter((s) => s.v);

  return (
    <>
      {/* ── Hero ───────────────────────────────────────── */}
      <section className="relative isolate overflow-hidden bg-ink text-white">
        <div className="blueprint absolute inset-0 -z-10" aria-hidden="true" />
        <div className="absolute top-1/3 -left-40 -z-10 size-[560px] rounded-full bg-brand/20 blur-[140px]" aria-hidden="true" />
        <div className="container-x grid min-h-[100svh] items-center gap-12 pt-28 pb-16 lg:grid-cols-[1.1fr_1fr] lg:gap-16 lg:pt-32">
          <div className="animate-fade-up">
            <p className="eyebrow">{t.home.eyebrow}</p>
            <h1 className="mt-5 text-[2.6rem] leading-[1.02] font-extrabold sm:text-6xl xl:text-7xl">
              {t.home.heroTitle} <span className="text-brand">{t.home.heroTitleAccent}</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/70 sm:text-xl">{t.home.heroText}</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href={pagePath(lang, "contact")} className="btn-primary !px-7 !py-4 text-base">
                {t.home.heroCta} <ArrowRight className="size-4" />
              </Link>
              <Link href={pagePath(lang, "projects")} className="btn-ghost !px-7 !py-4 text-base text-white">
                {t.home.heroCta2}
              </Link>
            </div>
            <ul className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-sm text-white/75">
              {t.home.usp.map((u) => (
                <li key={u} className="flex items-center gap-2">
                  <span className="grid size-5 place-items-center rounded-full bg-brand/20 text-brand">
                    <Check className="size-3" strokeWidth={3} />
                  </span>
                  {u}
                </li>
              ))}
            </ul>
          </div>

          <div className="relative animate-fade-up [animation-delay:150ms]">
            {settings.heroImage ? (
              <div className="relative">
                <div className="absolute -inset-3 -z-10 translate-x-6 translate-y-6 rounded-[2rem] border-2 border-brand/60" aria-hidden="true" />
                <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] shadow-lift sm:aspect-[5/5] lg:aspect-[4/5]">
                  <Image
                    src={settings.heroImage.src}
                    alt={settings.heroImage.alt[lang] || t.home.heroTitle}
                    fill
                    priority
                    sizes="(min-width: 1024px) 45vw, 100vw"
                    className="object-cover"
                  />
                </div>
              </div>
            ) : (
              <HeroVisual lang={lang} />
            )}
          </div>
        </div>

        {stats.length > 0 && (
          <div className="relative border-t border-white/10">
            <dl className="container-x grid grid-cols-1 divide-white/10 py-8 sm:grid-cols-3 sm:divide-x">
              {stats.map((s) => (
                <div key={s.l} className="py-3 sm:px-8 sm:first:pl-0">
                  <dt className="text-sm text-white/60">{s.l}</dt>
                  <dd className="font-display text-4xl font-extrabold text-white">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>
        )}
      </section>

      {/* ── Services ───────────────────────────────────── */}
      <section className="container-x py-20 lg:py-28" aria-labelledby="services-title">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="eyebrow">{t.home.servicesEyebrow}</p>
            <h2 id="services-title" className="mt-4 text-3xl font-extrabold sm:text-4xl lg:text-5xl">
              {t.home.servicesTitle}
            </h2>
            <p className="mt-4 text-lg text-stone">{t.home.servicesText}</p>
          </div>
          <Link href={pagePath(lang, "services")} className="btn-ghost shrink-0 self-start md:self-auto">
            {t.home.allServices} <ArrowRight className="size-4" />
          </Link>
        </div>
        <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <li key={s.key}>
              <Link
                href={servicePath(lang, s.key)}
                className={`group flex h-full flex-col rounded-[var(--radius-card)] border p-6 transition duration-300 hover:-translate-y-1 hover:shadow-lift ${
                  i < 2 ? "border-transparent bg-ink text-white" : "border-line bg-white"
                }`}
              >
                <span
                  className={`grid size-12 place-items-center rounded-2xl transition ${
                    i < 2 ? "bg-brand text-white" : "bg-brand-50 text-brand group-hover:bg-brand group-hover:text-white"
                  }`}
                >
                  <ServiceIcon name={s.icon} />
                </span>
                <h3 className="mt-6 text-lg font-bold">{s.title[lang]}</h3>
                <p className={`mt-2 flex-1 text-[15px] leading-relaxed ${i < 2 ? "text-white/65" : "text-stone"}`}>
                  {s.short[lang]}
                </p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-brand">
                  {t.services.more}
                  <ArrowRight className="size-4 transition group-hover:translate-x-1" />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      {/* ── Projects ───────────────────────────────────── */}
      {featured.length > 0 && (
        <section className="bg-sand/60 py-20 lg:py-28" aria-labelledby="projects-title">
          <div className="container-x">
            <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
              <div className="max-w-2xl">
                <p className="eyebrow">{t.home.projectsEyebrow}</p>
                <h2 id="projects-title" className="mt-4 text-3xl font-extrabold sm:text-4xl lg:text-5xl">
                  {t.home.projectsTitle}
                </h2>
                <p className="mt-4 text-lg text-stone">{t.home.projectsText}</p>
              </div>
              <Link href={pagePath(lang, "projects")} className="btn-dark shrink-0 self-start md:self-auto">
                {t.home.allProjects} <ArrowRight className="size-4" />
              </Link>
            </div>
            <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {featured.map((p, i) => (
                <li key={p.id} className={i === 0 && featured.length > 2 ? "sm:col-span-2 lg:row-span-2" : ""}>
                  <ProjectCard project={p} locale={lang} priority={i === 0} large={i === 0 && featured.length > 2} />
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* ── Why us ─────────────────────────────────────── */}
      <section className="container-x py-20 lg:py-28" aria-labelledby="why-title">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.3fr] lg:gap-20">
          <div className="lg:sticky lg:top-28 lg:self-start">
            <p className="eyebrow">{t.home.whyEyebrow}</p>
            <h2 id="why-title" className="mt-4 text-3xl font-extrabold sm:text-4xl lg:text-5xl">
              {t.home.whyTitle}
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-stone">{t.about.lead}</p>
            <Link href={pagePath(lang, "about")} className="btn-ghost mt-8">
              {t.nav.about} <ArrowRight className="size-4" />
            </Link>
          </div>
          <ul className="grid gap-4 sm:grid-cols-2">
            {t.home.why.map((w, i) => (
              <li key={w.t} className="card p-7">
                <span className="font-display text-sm font-bold text-brand">0{i + 1}</span>
                <h3 className="mt-4 text-xl font-bold">{w.t}</h3>
                <p className="mt-2 leading-relaxed text-stone">{w.d}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ── Process ────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-ink py-20 text-white lg:py-28" aria-labelledby="process-title">
        <div className="blueprint absolute inset-0" aria-hidden="true" />
        <div className="container-x relative">
          <p className="eyebrow">{t.home.processEyebrow}</p>
          <h2 id="process-title" className="mt-4 text-3xl font-extrabold sm:text-4xl lg:text-5xl">
            {t.home.processTitle}
          </h2>
          <ol className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
            {t.home.process.map((p, i) => (
              <li key={p.t} className="relative">
                <div className="flex items-center gap-4">
                  <span className="grid size-14 shrink-0 place-items-center rounded-full border-2 border-brand font-display text-xl font-extrabold text-brand">
                    {i + 1}
                  </span>
                  {i < 3 && <span className="hidden h-px flex-1 bg-gradient-to-r from-brand/60 to-transparent lg:block" aria-hidden="true" />}
                </div>
                <h3 className="mt-6 text-xl font-bold">{p.t}</h3>
                <p className="mt-2 leading-relaxed text-white/65">{p.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <SocialFollow locale={lang} settings={settings} />
      <CtaBanner locale={lang} settings={settings} />
    </>
  );
}

function HeroVisual({ lang }: { lang: Locale }) {
  const chips = services.slice(0, 4);
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[540px]" aria-hidden="true">
      <div className="absolute inset-[8%] rounded-full border border-white/10" />
      <div className="absolute inset-[20%] rounded-full border border-dashed border-white/15" />
      <div className="absolute inset-[26%] grid place-items-center rounded-full bg-gradient-to-br from-brand to-brand-700 shadow-[0_40px_120px_-20px_rgb(252_80_0/0.6)]">
        <Image src="/brand/mark.png" alt="" width={220} height={211} className="w-[52%] brightness-0 invert" priority />
      </div>
      {chips.map((s, i) => {
        const pos = ["top-[6%] left-[4%]", "top-[18%] right-0", "bottom-[16%] left-0", "bottom-[4%] right-[8%]"][i];
        return (
          <div
            key={s.key}
            className={`absolute ${pos} flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.07] px-4 py-3 text-sm font-semibold text-white shadow-lift backdrop-blur-md`}
          >
            <span className="grid size-9 place-items-center rounded-xl bg-brand text-white">
              <ServiceIcon name={s.icon} className="size-5" />
            </span>
            {s.title[lang]}
          </div>
        );
      })}
    </div>
  );
}
