import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Handshake, ShieldCheck, MessageCircle } from "lucide-react";
import type { Locale } from "@/lib/types";
import { getDictionary } from "@/lib/i18n";
import { pagePath } from "@/lib/routes";
import { buildMetadata, samePaths } from "@/lib/seo";
import { getSettings } from "@/lib/store";
import { PageHero } from "@/components/site/PageHero";
import { CtaBanner } from "@/components/site/CtaBanner";
import { SocialFollow } from "@/components/site/SocialFollow";

type Props = { params: Promise<{ lang: Locale }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { lang } = await params;
  const t = getDictionary(lang);
  return buildMetadata({
    locale: lang,
    title: t.about.metaTitle,
    description: t.about.metaDescription,
    paths: samePaths((l) => pagePath(l, "about")),
  });
}

const icons = [ShieldCheck, Handshake, MessageCircle];

export default async function AboutPage({ params }: Props) {
  const { lang } = await params;
  const t = getDictionary(lang);
  const settings = await getSettings();
  const img = settings.aboutImage || settings.heroImage;
  return (
    <>
      <PageHero
        eyebrow={t.nav.about}
        title={t.about.title}
        text={t.about.lead}
        crumbs={[
          { name: t.breadcrumbs.home, path: pagePath(lang, "home") },
          { name: t.nav.about, path: pagePath(lang, "about") },
        ]}
      />
      <section className="container-x grid gap-12 py-20 lg:grid-cols-2 lg:items-center lg:gap-20 lg:py-28">
        <div className="prose-ob text-lg">
          {t.about.body.map((p) => (
            <p key={p.slice(0, 30)}>{p}</p>
          ))}
          <div className="pt-4">
            <Link href={pagePath(lang, "projects")} className="btn-dark !no-underline !text-white">
              {t.home.heroCta2} <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
        <div className="relative">
          {img ? (
            <div className="relative aspect-[4/5] overflow-hidden rounded-[2rem] shadow-lift">
              <Image src={img.src} alt={img.alt[lang] || t.about.title} fill sizes="(min-width: 1024px) 45vw, 100vw" className="object-cover" />
            </div>
          ) : (
            <div className="blueprint-light relative grid aspect-[4/5] place-items-center overflow-hidden rounded-[2rem] bg-sand">
              <Image src="/brand/mark.png" alt="" width={240} height={230} className="w-1/2 opacity-90" />
            </div>
          )}
          <div className="absolute -bottom-6 -left-6 -z-10 size-40 rounded-[2rem] bg-brand" aria-hidden="true" />
        </div>
      </section>
      <section className="bg-sand/60 py-20 lg:py-24">
        <div className="container-x">
          <h2 className="text-3xl font-extrabold sm:text-4xl">{t.about.valuesTitle}</h2>
          <ul className="mt-10 grid gap-5 md:grid-cols-3">
            {t.about.values.map((v, i) => {
              const Icon = icons[i];
              return (
                <li key={v.t} className="card p-8">
                  <span className="grid size-12 place-items-center rounded-2xl bg-brand text-white">
                    <Icon className="size-6" strokeWidth={1.75} />
                  </span>
                  <h3 className="mt-6 text-xl font-bold">{v.t}</h3>
                  <p className="mt-2 leading-relaxed text-stone">{v.d}</p>
                </li>
              );
            })}
          </ul>
        </div>
      </section>
      <SocialFollow locale={lang} settings={settings} />
      <CtaBanner locale={lang} settings={settings} />
    </>
  );
}
